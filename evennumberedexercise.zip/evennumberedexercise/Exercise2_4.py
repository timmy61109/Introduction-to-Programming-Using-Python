pounds = eval(input("Enter a number in pounds: "))

kilograms = pounds * 0.454;

print(str(pounds) + " pounds is " + str(kilograms) + " kilograms")