import random

print(chr(random.randint(ord('A'), ord('Z'))))
