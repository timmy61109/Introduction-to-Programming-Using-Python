import turtle

turtle.penup()
turtle.goto(-50, 0)
turtle.pendown()
turtle.circle(50) 

turtle.penup()
turtle.goto(-50, -2 * 50)
turtle.pendown()
turtle.circle(50) 

turtle.penup()
turtle.goto(50, 0)
turtle.pendown()
turtle.circle(50) 

turtle.penup()
turtle.goto(50, -2 * 50)
turtle.pendown()
turtle.circle(50) 

turtle.done() 