import turtle

turtle.penup()
turtle.goto(-50, -50)
turtle.pendown()

turtle.goto(50, -50)
turtle.goto(50, 0)
turtle.goto(-50, 0)
turtle.goto(-50, -50)

turtle.goto(-25, -25)
turtle.goto(100 -25, -25)
turtle.goto(100 -25, 50 -25)

turtle.goto(-25, 50 -25)
turtle.goto(-25, -25)

turtle.penup()
turtle.goto(50, -50)
turtle.pendown()
turtle.goto(100 -25, -25)
        
turtle.penup()
turtle.goto(-50, 0)
turtle.pendown()
turtle.goto(-25, 25)
      
turtle.penup()
turtle.goto(100 -25, 25)
turtle.pendown()
turtle.goto(100-25 - 25, 25 - 25)
      
turtle.hideturtle()

turtle.done()