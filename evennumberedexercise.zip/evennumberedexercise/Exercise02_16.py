v0, v1, t = eval(input("Enter v0, v1, and t: "))
a = (v1 - v0) / t
print("The average acceleration is", a)
