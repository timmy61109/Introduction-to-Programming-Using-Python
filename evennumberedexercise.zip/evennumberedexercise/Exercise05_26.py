sum = 0
for i in range(1, 97 + 1, 2):
    sum += 1.0 * i / (i + 2)

print("sum is", sum)
