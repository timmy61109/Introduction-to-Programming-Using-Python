import turtle

turtle.right(60)
turtle.forward(50)
turtle.right(120)
turtle.forward(50)
turtle.right(120)
turtle.forward(50)

turtle.done() 